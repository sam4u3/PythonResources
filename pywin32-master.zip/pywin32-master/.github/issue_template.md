Note that issues in this repository are only for bugs or feature requests in the pywin32.

**If you need support or help using this package, please follow [these instructions](https://github.com/mhammond/pywin32/blob/master/README.md#support)** - support or help requests will be closed without comment.

For all bugs, please provide the following information.

* Expected behavior and actual behavior.

* Steps to reproduce the problem.

* Version of Python and pywin32
